# Curso Introducao ao Software R
# Script para importacao e exportacao de arquivos de dados 

# Defini??o da trilha de dados
# Usando a fun??o setwd
setwd("C:/Users/Windows/OneDrive - Experimental Analytics Corporation/Short course/Introdu??o ao software R - ao vivo/Material das aulas/Aula 1")

# Definindo a trilha SE o script estiver dentro da pasta
my.path <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(my.path)

# Ler o arquivo de dados no formato .csv
dados <- as.data.frame(fread("dados.csv"))

# Ler o arquivo de dados no formato .txt
dados <- as.data.frame(fread("dados.txt"))

# Salvar um arquivo de dados no formato de data frame
fwrite(dados, "Novo Arquivo de dados.csv")
fwrite(dados, "Novo Arquivo de dados.txt", sep=" ")

# Salvar um arquivo no formato de lista
resultado<-ea1(dados, design = 2)

capture.output(resultado, file = "Resultado_Anova.txt")

# Salvar gr?ficos
# Salvar em .pdf
# Abrir o arquivo em pdf
pdf("Exemplo.pdf") 
# Criar o gr?fico
plot(x = dados$Trat, y = dados$`Var 1`,
     pch = 16, frame = FALSE,
     xlab = "Trat", ylab = "", col = "#2E9FDF")
# Fechar o arquivo em pdf
dev.off() 

# Salvar em .jpeg
# Abrir o arquivo em jpeg
jpeg("Exemplo.jpg", width = 350, height = 350)
# Criar o gr?fico
plot(x = dados$Trat, y = dados$`Var 1`,
     pch = 16, frame = FALSE,
     xlab = "Trat", ylab = "", col = "#2E9FDF")
# Fechar o arquivo em jpeg
dev.off() 

# Salvar em .png
# Abrir o arquivo em png
png("Exemplo.png", width = 350, height = 350)
# Criar o gr?fico
plot(x = dados$Trat, y = dados$`Var 1`,
     pch = 16, frame = FALSE,
     xlab = "Trat", ylab = "", col = "#2E9FDF")
# Fechar o arquivo em jpeg
dev.off() 

# Salvar em .tiff
# Abrir o arquivo em png
tiff("Exemplo.tiff", width = 350, height = 350)
# Criar o gr?fico
plot(x = dados$Trat, y = dados$`Var 1`,
     pch = 16, frame = FALSE,
     xlab = "Trat", ylab = "", col = "#2E9FDF")
# Fechar o arquivo em jpeg
dev.off() 